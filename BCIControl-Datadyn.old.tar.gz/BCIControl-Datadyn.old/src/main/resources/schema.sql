CREATE TABLE piidata
(
 id varchar(111) NOT NULL ,
 NAME varchar(40) NOT NULL,
 ADDRESS varchar(100) NOT NULL ,
 EMAIL varchar(100) NOT NULL ,
 MOBILENO varchar(15) NOT NULL ,
 GENDER varchar(110) NOT NULL ,
 DOB varchar(110) NOT NULL ,
 PROFESSION varchar(110) NOT NULL ,
 PRIMARY KEY (id)
);
