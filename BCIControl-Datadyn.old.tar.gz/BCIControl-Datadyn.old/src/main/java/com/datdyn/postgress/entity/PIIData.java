package com.datdyn.postgress.entity;

public class PIIData {

	String piiId;
	String piiName;
	String piiAddress;
	String piiEmail;
	String piiMobileno;
	String piiGender;
	String piiDOB;
	String piiProfession;
	
	
	public String getPiiId() {
		return piiId;
	}
	public void setPIIDataId(String piiId) {
		this.piiId = piiId;
	}
	public String getPiiName() {
		return piiName;
	}
	public void setPIIDataName(String piiName) {
		this.piiName = piiName;
	}
	public String getPiiAddress() {
		return piiAddress;
	}
	public void setPIIDataAddress(String piiAddress) {
		this.piiAddress = piiAddress;
	}
	public String getPiiEmail() {
		return piiEmail;
	}
	public void setPIIDataEmail(String piiEmail) {
		this.piiEmail = piiEmail;
	}
	public String getPiiMobileno() {
		return piiMobileno;
	}
	public void setPIIDataMobileno(String piiMobileno) {
		this.piiMobileno = piiMobileno;
	}
	public String getPiiGender() {
		return piiGender;
	}
	public void setPIIDataGender(String piiGender) {
		this.piiGender = piiGender;
	}
	public String getPiiDOB() {
		return piiDOB;
	}
	public void setPIIDataDOB(String piiDOB) {
		this.piiDOB = piiDOB;
	}
	public String getPiiProfession() {
		return piiProfession;
	}
	public void setPIIDataProfession(String piiProfession) {
		this.piiProfession = piiProfession;
	}
	
}
